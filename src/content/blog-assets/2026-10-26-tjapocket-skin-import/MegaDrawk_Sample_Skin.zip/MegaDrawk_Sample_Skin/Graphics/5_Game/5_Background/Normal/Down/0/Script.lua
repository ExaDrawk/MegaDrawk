function init() func:AddGraph("Paper.png") end
function update() end
function draw() func:DrawGraph(0, 191, "Paper.png") end
