local elapsed = 0
function init()
    func:AddGraph("Banner.png")
    func:AddGraph("Rays.png")
end
function playEndAnime(player) elapsed = 0 end
function update(player) elapsed = elapsed + deltaTime end
function draw(player)
    local t = math.min(1, elapsed / 0.38)
    local scale = 0.96 + 0.04 * (1-(1-t)^3)
    func:SetOpacity(math.min(255, elapsed * 1600), "Banner.png")
    func:SetScale(scale, scale, "Banner.png")
    func:DrawGraphCenter(814, 256, "Banner.png")
    func:SetOpacity(math.max(0, 190 * (1-elapsed/1.2)), "Rays.png")
    func:SetScale(0.92 + math.min(elapsed,1.2)*0.15, 1, "Rays.png")
    func:DrawGraphCenter(814, 256, "Rays.png")
end
