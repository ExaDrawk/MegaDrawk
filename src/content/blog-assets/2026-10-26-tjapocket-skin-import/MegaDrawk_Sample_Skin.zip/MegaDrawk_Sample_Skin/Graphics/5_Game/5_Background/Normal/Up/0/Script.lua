local elapsed = 0
function init()
    func:AddGraph("Paper.png")
    func:AddGraph("Accent.png")
end
function update() elapsed = elapsed + deltaTime * (bpm[0] or 120) / 60 end
function draw()
    func:DrawGraph(0, 0, "Paper.png")
    func:SetOpacity(((isGogo and isGogo[0]) and 135 or 55) + 25 * math.sin(elapsed * math.pi * 2), "Accent.png")
    func:DrawGraph(0, 187, "Accent.png")
end
